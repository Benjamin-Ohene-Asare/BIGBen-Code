// Code for expanding images on click
const expandImg = document.querySelector(".expand");
const smallImg = document.querySelectorAll(".small-img img");

smallImg.forEach((image) => {
  image.addEventListener("click", () => {
    expandImg.querySelector("img").src = image.src; // Set the source of expanded image to the clicked image source
    expandImg.style.display = "block"; // Display the expanded image container
  });
});

// Code for expanding images (expand2)
const expandImg2 = document.querySelector(".expand2");
const smallImg2 = document.querySelectorAll(".small-img2 img");

smallImg2.forEach((image) => {
  image.addEventListener("click", () => {
    expandImg2.querySelector("img").src = image.src; // Set the source of expanded image to the clicked image source
    expandImg2.style.display = "block"; // Display the expanded image container
  });
});

// Code for expanding images (expand3)
const expandImg3 = document.querySelector(".expand3");
const smallImg3 = document.querySelectorAll(".small-img3 img");

smallImg3.forEach((image) => {
  image.addEventListener("click", () => {
    expandImg3.querySelector("img").src = image.src; // Set the source of expanded image to the clicked image source
    expandImg3.style.display = "block"; // Display the expanded image container
  });
});

// Code for showing search bar on button click
const searchButton = document.getElementById("search");
const searchBar = document.querySelector(".form");
const removeButton = document.getElementById("remove");

searchButton.addEventListener("click", () => {
  searchBar.style.display = "block"; // Display the search bar
});

removeButton.addEventListener("click", () => {
  searchBar.style.display = "none"; // Hide the search bar
});

// Code for toggling menu links
const menuIcon = document.querySelector(".menu img");
const menuLinks = document.querySelector(".menu-links");

menuIcon.addEventListener("click", () => {
  if (menuLinks.style.display === "block") {
    menuLinks.style.display = "none"; // Hide the menu links if already visible
  } else {
    menuLinks.style.display = "block"; // Show the menu links if hidden
  }
});

// Code for adding/removing class on scroll
window.addEventListener("scroll", () => {
  const header = document.querySelector("header");
  const scrollEffect = window.scrollY;

  if (scrollEffect > 10) {
    header.classList.add("fixed"); // Add the "fixed" class to the header when scrolled beyond a certain point
  } else {
    header.classList.remove("fixed"); // Remove the "fixed" class from the header when scrolled back to the top
  }
});
